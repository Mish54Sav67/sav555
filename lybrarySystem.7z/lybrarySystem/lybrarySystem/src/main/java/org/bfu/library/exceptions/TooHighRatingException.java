package org.bfu.library.exceptions;


public class TooHighRatingException extends Exception{

    public TooHighRatingException() {
        System.err.println("Рейтинг должен быть от 1 до 5 звёзд!");
    }
}
