package org.bfu.db;

import org.bfu.library.entities.Author;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.util.List;


public class AuthorQuery {
    EntityManager em;
    EntityManagerFactory emf;

    public AuthorQuery() {
        emf=Persistence.createEntityManagerFactory("LibraryPU");
        em=emf.createEntityManager();
        em.getTransaction().begin();
    }
    
    public List<Author> listOfAuthor(){
        return em.createNamedQuery("Author.findAll", Author.class).getResultList();
    }
    
    public boolean addAuthor(Author author)
    {
        try {
            em.persist(author);
            em.getTransaction().commit();
            return true;
        } catch(Exception e) {
            System.out.println(e.toString());
            return false;
        } 
    }
}
