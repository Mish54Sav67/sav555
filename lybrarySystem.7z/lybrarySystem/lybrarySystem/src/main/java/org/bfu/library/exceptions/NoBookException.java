package org.bfu.library.exceptions;


public class NoBookException extends NullPointerException {

    public NoBookException() {
        System.err.println("Количество книг не может быть равным нулю!");
    }
    
}
