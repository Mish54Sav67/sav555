/** 
 * 
 *      NewAccount
 *      ^    \
 *      |     \                       BorrowPage
 *      |      \                    /
 *      |  MyAccount (regular user)<
 *      | /                         \
 *      |/                            ReviewPage
 * Login<
 *       \                       AddBook
 *        \                    /
 *         MyLibrarianAccount<
 *                             \
 *                               BookHistory
 * 
 */
package org.bfu.library.controllers;

import org.bfu.db.LoginQuery;
import org.bfu.library.entities.Persons;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;



public class LoginController implements Initializable {

    @FXML
    private TextField username;
    
    @FXML
    private PasswordField password;
    
    @FXML
    private Label message;
    
    @FXML
    private Label signUpMessage; 
    
    private List<Persons> listLogin = new ArrayList<>();
    private LoginQuery query = new LoginQuery();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        listLogin = query.listOfLogin();
    }   
    
    @FXML
    private void loginAction(ActionEvent event) throws IOException
    { 
        boolean foundId=false;
        for (Persons users : listLogin) {
            if (username.getText().equals(users.getUsername())){
                foundId=true;
                if (password.getText().equals(users.getEntryKey())) {
                    if (!users.getAccess()) {
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/bfu/library/MyAccount.fxml"));
                        Parent parent = loader.load(); 
                        MyAccountController controller=(MyAccountController)loader.getController();
                        controller.setPerson(users); 
                        Scene scene = new Scene(parent);
                        Stage stage = new Stage();
                        stage.setTitle("Welcome "+users.getUsername());
                        stage.setScene(scene);
                        stage.show();
                        Stage oldStage = (Stage) message.getScene().getWindow();
                        oldStage.close();
                    }
                    else{
                        FXMLLoader loader = new FXMLLoader(getClass().getResource("/org/bfu/library/MyLibrarianAccount.fxml"));
                        Parent parent = loader.load();
                        MyLibrarianAccountController controller=(MyLibrarianAccountController)loader.getController();
                        controller.setPerson(users);
                        Scene scene = new Scene(parent);
                        Stage stage = new Stage();
                        stage.setTitle("Welcome "+users.getUsername());
                        stage.setScene(scene);
                        stage.show();
                        Stage oldStage = (Stage) message.getScene().getWindow();
                        oldStage.close();
                    }
               }
                else {
                    message.setText("Неверный пароль");
                }
            }
            
        }
        if (foundId==false){
            message.setText("Неверное имя пользователя");
        }
  
    }
    
    @FXML
    private void signUpAction (ActionEvent event) throws IOException
    {
        Parent parent = FXMLLoader.load(getClass().getResource("/org/bfu/library/NewAccount.fxml"));
        Scene scene= new Scene(parent);
        Stage stage= new Stage();
        stage.setTitle("Создать учётную запись");
        stage.setScene(scene);
        stage.show();
        Stage oldStage = (Stage) message.getScene().getWindow(); 
        oldStage.close();
    }
}
