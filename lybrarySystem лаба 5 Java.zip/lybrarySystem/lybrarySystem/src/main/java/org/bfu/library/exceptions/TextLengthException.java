package org.bfu.library.exceptions;

public class TextLengthException extends Exception{

    public TextLengthException() {
        System.err.println("Максимальная длина - 500 символов");;
    }
}
